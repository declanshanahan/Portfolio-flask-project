// Assuming you have a function to get the current page name (e.g., 'about.html')
const currentPage = getCurrentPageName();

// Select all navigation links
const navLinks = document.querySelectorAll('.nav-link');

// Loop through each link
navLinks.forEach(link => {
  // Check if the link's class matches the current page name
  if (link.classList.contains(currentPage)) {
    link.classList.add('active'); // Add the 'active' class
  }
});
